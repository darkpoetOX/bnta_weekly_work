package com.bnta.word_guesser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordGuesserApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordGuesserApplication.class, args);
	}

}
